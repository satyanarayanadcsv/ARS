package com.cg.airline.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.exception.AirLineException;
import com.cg.airline.service.AirLineServiceImpl;
import com.cg.airline.beans.AirLineFlightInfoDTO;;

public class AirLineMain {
	public static Scanner in;
	public static AirLineServiceImpl service = new AirLineServiceImpl();
	public static String role;
	public static String username;
	public static String password;
	public static String flightno;
	public static String airline;
	public static String src_city;
	public static String dest_city;
	public static String dep_date;
	public static String arr_date;
	public static String dep_time;
	public static String arr_time;
	public static int eseats;
	public static int eseat_fare;
	public static int bseats;
	public static int bseat_fare;
	public static Date date1;
	public static Date date2;
	public static void main(String[] args) throws AirLineException, ParseException {
		in = new Scanner(System.in);
		System.out
				.println("------:Welcome to The AirLine Reservation System:-------");
		String choice = "initial";
		while (!choice.equals("4")) {
			System.out.println("Enter Your choice: ");
			System.out.println("1. User/ customer");
			System.out.println("2. Admin");
			System.out.println("3. Airline Executive");
			System.out.println("4. Exit");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				getUser();
				break;
			case "2":
				
				admin();
				break;
			case "3":
				airlineExecutive();
				break;
			case "4":
				System.out.println("Thank You!");
				System.exit(0);
				break;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
	}

	static Boolean getUser() throws AirLineException {

		in = new Scanner(System.in);
		String choice = "initial";
		while (!choice.equals("4")) {
			System.out.println("1. Book Ticket");
			System.out.println("2. View Flight Schedule");
			System.out.println("3. View Ticket");
			System.out.println("4. Return to Main Menu");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				bookTicket();
				break;
			case "2":

				break;
			case "3":

				break;
			case "4":
				return false;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
		return true;
	}

	static void bookTicket() throws AirLineException {

		int no_of_passengers;
		String class_type;
		double total_fare;
		String seat_number;
		String payment_mode;
		String custMail;
		
		AirLineBookInfoDTO dto=new AirLineBookInfoDTO();
		
		System.out.println("Enter Source city");
		src_city=in.next();
		System.out.println("Enter Destination city");
		dest_city=in.next();
		
		ArrayList<AirLineFlightInfoDTO> airDto= new ArrayList<AirLineFlightInfoDTO>();
		airDto=service.showFlights(src_city, dest_city);
		
		System.out.println("Enter email");
		custMail = in.next();
		
		System.out.println("Enter no of passenegers");
		no_of_passengers = in.nextInt();
		
		
		String choice = "initial";
		while (true) {
			System.out.println("Enter Class Type");
			System.out.println("1.First Seat");
			System.out.println("2.Bus Seat");
			choice = in.next();
			if(choice.equals("1"))
			{
				class_type = "First Seat";
				total_fare = no_of_passengers * 10000;
				break;
			}
			else if(choice.equals("2"))
			{
				class_type = "Bus Seat";
				total_fare = no_of_passengers * 20000;
				break;
			}
			else{
				System.out.println("Invalid choice");
			}
		}

		System.out.println("Enter Seat Numbers");
		seat_number = in.next();
		
		System.out.println("Enter  flight Number");
		flightno = in.next();
		
		System.out.println("Enter Payment Mode");
		payment_mode = in.next();
		
		dto.setCust_email(custMail);
		dto.setClass_type(class_type);
		dto.setpayment_mode(payment_mode);
		dto.setDest_city(dest_city);
		dto.setSrc_city(src_city);
		dto.setFlightno(flightno);
		dto.setNo_of_passengers(no_of_passengers);
		dto.setTotal_fare(total_fare);
		dto.setSeat_number(seat_number);
		service.bookTicket(dto);
	}
	static boolean validUser(String role)throws AirLineException{
		in = new Scanner(System.in);
		System.out.println("Enter Username:" );
		username = in.next();
		System.out.println("Eneter Password:" );
		password = in.next();
		return service.validUser(username,password,role);
		 
	}
	static void airlineExecutive() throws AirLineException{
		role = "Airline Executive";
		if(validUser(role)){
			in = new Scanner(System.in);
			String choice = "initial";
			while (!choice.equals("2")) {
				System.out.println("1. View Flight Schedule");
				System.out.println("2. Return to Main Menu");
				choice = in.next().trim();
				switch (choice) {
				case "1":
					System.out.println("**********Available Schedule**********");
					viewSchedule();
					break;
				case "2":
					break;
				default:
					System.out.println("Please Select valid choice");
					break;
				
				}
		}
		}
		else
			System.out.println("Enter Valid Username And Password");
		}
		
	static boolean admin() throws AirLineException, ParseException {
		role = "Administrator";
		if(validUser(role)){
		String choice = "initial";
		while (!choice.equals("6")) {
			System.out.println("1. Add New Flight");
			System.out.println("2. Delete Flight");
			System.out.println("3. View Flight Schedule");
			System.out.println("4. Update Flight Schedule");
			System.out.println("5. Search Flight");
			System.out.println("6. Return to Main Menu");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				addFlight();
				break;
			case "2":
				deleteFlight();
				break;
			case "3":
				viewSchedule();
				break;
			case "4":
				updateSchedule();
				break;
			case "5":
				searchFlight();
				break;
			case "6":
				return false;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
		}else
			System.out.println("Enter Valid Username and Password");
		return true;
	}
		private static void addFlight() throws AirLineException{
			
			in = new Scanner(System.in);
			System.out.println("Enter  flight Number: ");
			flightno = in.next();
			System.out.println("Enter Airline Name: ");
			airline = in.next();
			System.out.println("Enter Source city: ");
			src_city = in.next();
			System.out.println("Enter Destination city: ");
			dest_city = in.next();
			System.out.println("Enter Departure Date(dd-mm-yyyy): ");
			dep_date = in.next();
			System.out.println("Enter Arrival Date(dd-mm-yyyy): ");
			arr_date = in.next();
			System.out.println("Enter Departure Time(24HOUR FORMAT): ");
			dep_time = in.next();
			System.out.println("Enter Arrival Time(24HOUR FORMAT): ");
			arr_time = in.next();
			System.out.println("Enter Number of Economy Class Seats: ");
			eseats = in.nextInt();
			System.out.println("Enter Economy Class Seat Fare: ");
			eseat_fare = in.nextInt();
			System.out.println("Enter Number of Business Class Seats: ");
			bseats = in.nextInt();
			System.out.println("Enter Business Class Seat Fare: ");
			bseat_fare = in.nextInt();
			
			AirLineFlightInfoDTO addFlightDto = new AirLineFlightInfoDTO();
			addFlightDto.setFlightNo(flightno);
			addFlightDto.setAirLine(airline);
			addFlightDto.setDept_city(src_city);
			addFlightDto.setArr_city(dest_city);
			try {
				addFlightDto.setDept_date(new SimpleDateFormat("dd-mm-yyyy").parse(dep_date));
				addFlightDto.setArr_date(new SimpleDateFormat("dd-mm-yyyy").parse(arr_date));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			addFlightDto.setDept_time(dep_time);
			addFlightDto.setArr_time(arr_time);
			addFlightDto.setFirst_seats(eseats);
			addFlightDto.setFirst_seats_fare(eseat_fare);
			addFlightDto.setBus_seats(bseats);
			addFlightDto.setBus_seats_fare(bseat_fare);
			
			addFlightDto= service.addFlight(addFlightDto);
			
			
		}
		private static void deleteFlight() throws AirLineException{
			System.out.println("Enter Flight Number: ");
			flightno = in.next();
			service.deleteFlight(flightno);
		}
		private static void viewSchedule() throws AirLineException{
			List<AirLineFlightInfoDTO> flightList = new ArrayList<AirLineFlightInfoDTO>();
			flightList = service.viewSchedule();
		
			if (flightList != null){
				Iterator<AirLineFlightInfoDTO> itr = flightList.iterator();
				System.out.println("Flight No  Airline     Source     Destination  Departure Date   Arrival Date  "
						+ "Departure Time  Arrival Time  "
						+ "Economy Seats  Economy Fare  Business Seats  Business Fare");
				while(itr.hasNext()){
					AirLineFlightInfoDTO dtoObj1 = (AirLineFlightInfoDTO) itr.next();
					System.out.println(dtoObj1.getFlightNo() +"  "+ dtoObj1.getAirLine()+"  "+ dtoObj1.getDept_city()
							+"  "+ dtoObj1.getArr_city() +"  "+dtoObj1.getDept_date() +"  "+dtoObj1.getArr_date() 
							+"  "+dtoObj1.getDept_time()+"  "+ dtoObj1.getArr_time()+"  "+ dtoObj1.getFirst_seats()
							+"  "+dtoObj1.getFirst_seats_fare() +"  "+ dtoObj1.getBus_seats() 
							+"  "+dtoObj1.getBus_seats_fare());
				}
				
			}
			else
				System.out.println("No Schedule Available");
		}
	private static void searchFlight () throws AirLineException{
		System.out.println("Enter Flight Number: ");
		flightno = in.next();
		List<AirLineFlightInfoDTO> searchList = new ArrayList<AirLineFlightInfoDTO>();
		searchList =service.searchFlight(flightno);
		System.out.println("***********Flight Schedule***********");
		if (searchList != null){
			Iterator<AirLineFlightInfoDTO> itr = searchList.iterator();
			System.out.println("Flight No  Airline     Source     Destination  Departure Date   Arrival Date  "
					+ "Departure Time  Arrival Time  "
					+ "Economy Seats  Economy Fare  Business Seats  Business Fare");
			while(itr.hasNext()){
				AirLineFlightInfoDTO dtoObj1 = (AirLineFlightInfoDTO) itr.next();
				System.out.println(dtoObj1.getFlightNo() +"  "+ dtoObj1.getAirLine()+"  "+ dtoObj1.getDept_city()
						+"  "+ dtoObj1.getArr_city() +"  "+dtoObj1.getDept_date() +"  "+dtoObj1.getArr_date() 
						+"  "+dtoObj1.getDept_time()+"  "+ dtoObj1.getArr_time()+"  "+ dtoObj1.getFirst_seats()
						+"  "+dtoObj1.getFirst_seats_fare() +"  "+ dtoObj1.getBus_seats() 
						+"  "+dtoObj1.getBus_seats_fare());
			}
			
		}
		else
			System.out.println("No Schedule Available");
		
	}
	private static boolean updateSchedule() throws AirLineException{
		in = new Scanner(System.in);
		String choice = "initial";
		while (!choice.equals("4")) {
			System.out.println("1. Update Source-Destination City");
			System.out.println("2. Update Departure-Arrival  Date");
			System.out.println("3. Update Departure-Arrival By Time");
			System.out.println("4. Return to Previous Menu");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				updateCity();
				break;
			case "2":
				updateDate();
				break;
			case "3":
				updateTime();
				break;
			case "4":
				return false;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
		return true;
	}
	private static void updateCity()throws AirLineException{
		System.out.println("Enter Flight Number: ");
		flightno = in.next();
		System.out.println("Enter Updated Source City: ");
		src_city = in.next();
		System.out.println("Enter Updated Destination City: ");
		dest_city = in.next();
		service.updateCity(flightno,src_city,dest_city);
	}
	private static void updateDate()throws AirLineException{
		System.out.println("Enter Flight Number: ");
		flightno = in.next();
		System.out.println("Enter Updated Departure Date: ");
		dep_date = in.next();
		System.out.println("Enter Updated Arrival Date: ");
		arr_date = in.next();
		try {
			service.updateDate(flightno,new SimpleDateFormat("dd-MM-yyyy").parse(dep_date),
					new SimpleDateFormat("dd-MM-yyyy").parse(arr_date));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void updateTime()throws AirLineException{
		System.out.println("Enter Flight Number: ");
		flightno = in.next();
		System.out.println("Enter Updated Departure Time(24HOUR FORMAT): ");
		dep_time = in.next();
		System.out.println("Enter Updated Arrival Time(24HOUR FORMAT): ");
		arr_time = in.next();
		service.updateTime(flightno,dep_time,arr_time);
	}
	}

