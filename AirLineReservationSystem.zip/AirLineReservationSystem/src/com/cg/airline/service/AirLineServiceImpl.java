package com.cg.airline.service;

import java.util.ArrayList;
import java.util.Date;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.beans.AirLineFlightInfoDTO;
import com.cg.airline.dao.AirLineDAOImpl;
import com.cg.airline.exception.AirLineException;

public class AirLineServiceImpl implements IAirLineService{
	AirLineDAOImpl dao;
	
	
	public AirLineServiceImpl() {
		dao =new AirLineDAOImpl();
	}
	
	@Override
	public void bookTicket(AirLineBookInfoDTO dto) throws AirLineException{
		dao.bookTicket(dto);
	}
	
	@Override
	public ArrayList<AirLineFlightInfoDTO> showFlights(String src_city, String dest_city) throws AirLineException{
		return dao.showFlights(src_city, dest_city);
	}
	public AirLineFlightInfoDTO addFlight(AirLineFlightInfoDTO addFlightDto) throws AirLineException{
		return dao.addFlight(addFlightDto);
	}
	public String deleteFlight(String flightno) throws AirLineException{
		return dao.deleteFlight(flightno);
	}
	public ArrayList<AirLineFlightInfoDTO> viewSchedule() throws AirLineException{
		return dao.viewSchedule();
	}
	public ArrayList<AirLineFlightInfoDTO> searchFlight(String flightno) throws AirLineException{
		return dao.searchFlight(flightno);
	}
	public void updateCity(String flightno,String src_city,String dest_city)throws AirLineException{
		 dao.updateCity(flightno,src_city,dest_city);
	}
	public void updateDate(String flightno,Date dep_date,Date arr_date)throws AirLineException{
		dao.updateDate(flightno,dep_date,arr_date);
	}
	public void updateTime(String flightno,String dep_time, String arr_time)throws AirLineException{
		dao.updateTime(flightno,dep_time,arr_time);
	}
	public boolean validUser(String username,String password, String role)throws AirLineException{
		return dao.validUser(username,password, role);
	}
}
