package com.cg.airline.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.beans.AirLineFlightInfoDTO;
import com.cg.airline.exception.AirLineException;
import com.cg.airline.util.DBconnection;

public class AirLineDAOImpl implements IAirLineDAO {
	AirLineFlightInfoDTO dtoObj=null;
	@Override
	public void bookTicket(AirLineBookInfoDTO dto) throws AirLineException {

		Connection conn;
		PreparedStatement insertStmt;
		try {

			conn = DBconnection.getConnection();
			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, dto.getCust_email());
			insertStmt.setInt(2, dto.getNo_of_passengers());
			insertStmt.setString(3, dto.getClass_type());
			insertStmt.setDouble(4, dto.getTotal_fare());
			insertStmt.setString(5, dto.getSeat_number());
			insertStmt.setString(6, dto.getpayment_mode());
			insertStmt.setString(7, dto.getSrc_city());
			insertStmt.setString(8, dto.getDest_city());
			insertStmt.setString(9, dto.getFlightno());

			int set = insertStmt.executeUpdate();
			if (set != 1) {
				throw new AirLineException(
						"Sorry can not proccess your request");
			} else {
				System.out.println("Successfully Saved Booking Details");
				conn.commit();
				insertStmt.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public ArrayList<AirLineFlightInfoDTO> showFlights(String src_city,
			String dest_city) throws AirLineException {
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		ArrayList<AirLineFlightInfoDTO> airDto = new ArrayList<AirLineFlightInfoDTO>();
		try {
			conn = DBconnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_FLIGHTS);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				AirLineFlightInfoDTO bn = new AirLineFlightInfoDTO();

				airDto.add(bn);
			}
		} catch (AirLineException e) {
			throw new AirLineException("sorry not updated");
		} catch (SQLException e) {
			throw new AirLineException("sorry not updated");
		}
		return airDto;
	}

	public AirLineFlightInfoDTO addFlight(AirLineFlightInfoDTO addFlightDto)
			throws AirLineException {
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement insert = null;
		conn = DBconnection.getConnection();
		try {
			
			
			insert = conn.prepareStatement(IQueryMapper.INSERT_FLIGHT);
			insert.setString(1, addFlightDto.getFlightNo());
			insert.setString(2, addFlightDto.getAirLine());
			insert.setString(3, addFlightDto.getDept_city());
			insert.setString(4, addFlightDto.getArr_city());
			insert.setDate(5, new java.sql.Date(addFlightDto.getDept_date().getTime()));
			insert.setDate(6, new java.sql.Date(addFlightDto.getArr_date().getTime()));
			insert.setString(7, addFlightDto.getDept_time());
			insert.setString(8, addFlightDto.getArr_time());
			insert.setInt(9, addFlightDto.getFirst_seats());
			insert.setInt(10, addFlightDto.getFirst_seats_fare());
			insert.setInt(11, addFlightDto.getBus_seats());
			insert.setInt(12, addFlightDto.getBus_seats_fare());
			int result = insert.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			System.out.println(e);
		}

		return addFlightDto;

	}
	public String deleteFlight(String flightno) throws AirLineException{
		Connection conn;
		
		PreparedStatement deleteStmt = null;
		try {
			conn = DBconnection.getConnection();
			deleteStmt = conn.prepareStatement(IQueryMapper.DELETE_FLIGHT);
			deleteStmt.setString(1, flightno);
			int delete = deleteStmt.executeUpdate();
			if(delete!=1){
				//logger.error("Deletion Failed");
				throw new AirLineException("Deletion Failed");
			}else {System.out.println("\nRecord Deleted");}
		}catch(SQLException e){
			System.out.println(e);
		}
		return flightno;
	}
	public ArrayList<AirLineFlightInfoDTO> viewSchedule() throws AirLineException{
		
		Connection conn;
		PreparedStatement getViewStmt = null;
		ResultSet viewResult = null;
		 ArrayList<AirLineFlightInfoDTO> view = new  ArrayList<AirLineFlightInfoDTO>();

			try {
				conn = DBconnection.getConnection();
				getViewStmt = conn.prepareStatement(IQueryMapper.GET_FLIGHTS);
				viewResult = getViewStmt.executeQuery();
				while (viewResult.next()) {
				dtoObj = new AirLineFlightInfoDTO();
				dtoObj.setFlightNo(viewResult.getString(1));
				dtoObj.setAirLine(viewResult.getString(2));
				dtoObj.setDept_city(viewResult.getString(3));
				dtoObj.setArr_city(viewResult.getString(4));
				dtoObj.setDept_date(viewResult.getDate(5));
				dtoObj.setArr_date(viewResult.getDate(6));
				dtoObj.setDept_time(viewResult.getString(7));
				dtoObj.setArr_time(viewResult.getString(8));
				dtoObj.setFirst_seats(viewResult.getInt(9));
				dtoObj.setFirst_seats_fare(viewResult.getInt(10));
				dtoObj.setBus_seats(viewResult.getInt(11));
				dtoObj.setBus_seats_fare(viewResult.getInt(12));
				view.add(dtoObj);
				}
				}	catch (AirLineException | SQLException exception2) {
					//logger.error(exception2.getMessage());
					System.out.println(exception2);
				}

				return view;
	}
	public ArrayList<AirLineFlightInfoDTO> searchFlight(String flightno) throws AirLineException{
		Connection conn;
		PreparedStatement getsearchStmt = null;
		ResultSet searchResult = null;
		 ArrayList<AirLineFlightInfoDTO> search = new  ArrayList<AirLineFlightInfoDTO>();
		 try {
				conn = DBconnection.getConnection();

				getsearchStmt = conn.prepareStatement(IQueryMapper.SEARCH_FLIGHT);
				getsearchStmt.setString(1, flightno);
				searchResult = getsearchStmt.executeQuery();
				while (searchResult.next()) {
					dtoObj = new AirLineFlightInfoDTO();
					dtoObj.setFlightNo(searchResult.getString(1));
					dtoObj.setAirLine(searchResult.getString(2));
					dtoObj.setDept_city(searchResult.getString(3));
					dtoObj.setArr_city(searchResult.getString(4));
					dtoObj.setDept_date(searchResult.getDate(5));
					dtoObj.setArr_date(searchResult.getDate(6));
					dtoObj.setDept_time(searchResult.getString(7));
					dtoObj.setArr_time(searchResult.getString(8));
					dtoObj.setFirst_seats(searchResult.getInt(9));
					dtoObj.setFirst_seats_fare(searchResult.getInt(10));
					dtoObj.setBus_seats(searchResult.getInt(11));
					dtoObj.setBus_seats_fare(searchResult.getInt(12));
					search.add(dtoObj);
				}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					//logger.error(e.getMessage());
					System.out.println(e);
				} catch (AirLineException exception2) {
					//logger.error(exception2.getMessage());
					System.out.println(exception2);
				}
		 return search;
	}
	public void updateCity(String flightno,String src_city,String dest_city)throws AirLineException{
		Connection conn;
		PreparedStatement updateCityStmt = null;
		//ResultSet updateCityResult = null;
		conn = DBconnection.getConnection();
		try {
			updateCityStmt = conn.prepareStatement(IQueryMapper.UPDATE_PLACE);
			updateCityStmt.setString(1, src_city);	
			updateCityStmt.setString(2, dest_city);	
			updateCityStmt.setString(3, flightno);	
			int update = updateCityStmt.executeUpdate();
			if(update!=1){
				//logger.error("Deletion Failed");
				throw new AirLineException("Updating records Failed");
			}else {System.out.println("\nRecord Updated");}
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
	}
	public void updateDate(String flightno,Date dep_date,Date arr_date)throws AirLineException{
		Connection conn;
		PreparedStatement updateDateStmt = null;
		//ResultSet updateDateResult = null;
		
		try {
			conn = DBconnection.getConnection();
			
			System.out.println(new java.sql.Date(dep_date.getTime()));
			updateDateStmt = conn.prepareStatement(IQueryMapper.UPDATE_DATE);
			updateDateStmt.setDate(1, new java.sql.Date(dep_date.getTime()));
			updateDateStmt.setDate(2, new java.sql.Date(arr_date.getTime()));	
			updateDateStmt.setString(3, flightno);	
			int update = updateDateStmt.executeUpdate();
			if(update!=1){
				//logger.error("Updation Failed");
				throw new AirLineException("Updating records Failed");
			}else {System.out.println("\nRecord Updated");}
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
	}
	public void updateTime(String flightno,String dep_time, String arr_time)throws AirLineException{
		Connection conn;
		PreparedStatement updateTimeStmt = null;
		//ResultSet updateTimeResult = null;
		
		try {
			conn = DBconnection.getConnection();
			updateTimeStmt = conn.prepareStatement(IQueryMapper.UPDATE_TIME);
			updateTimeStmt.setString(1, dep_time);	
			updateTimeStmt.setString(2, arr_time);	
			updateTimeStmt.setString(3, flightno);	
			int update = updateTimeStmt.executeUpdate();
			if(update!=1){
				//logger.error("Deletion Failed");
				throw new AirLineException("Updating records Failed");
			}else {System.out.println("\nRecord Updated");}
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
	}
	public boolean validUser(String username,String password, String role)throws AirLineException{
		Connection conn;
		PreparedStatement validUserStmt = null;
		ResultSet validUserResult = null;
		
		try {
			conn = DBconnection.getConnection();
			validUserStmt = conn.prepareStatement(IQueryMapper.VALID_USER);
			validUserStmt.setString(1, role);
			validUserResult = validUserStmt.executeQuery();
			while(validUserResult.next()){
				String user = validUserResult.getString(1);
				String pass = validUserResult.getString(2);
				if(user.equals(username) && pass.equals(password)){
					
					return true;
				
					}
				else{
					System.out.println("ERROR!!! Not valid");
					
				}
			}
			
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
		return false;
	}

	
}
