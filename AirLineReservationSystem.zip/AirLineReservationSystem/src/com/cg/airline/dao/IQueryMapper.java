package com.cg.airline.dao;

public interface IQueryMapper {

	String INSERT_QUERY = "INSERT INTO BOOKINGINFORMATION VALUES(air_booking_id.nextval ,?,?,?,?,?,?,?,?,?)";
	String GET_FLIGHTS = "select * from FLIGHTINFORMATION";
	String SEARCH_FLIGHT ="select * from FLIGHTINFORMATION where flightno=?";
	String INSERT_FLIGHT="insert into flightinformation values(?,?,?,?,?,?,?,?,?,?,?,?)";
	String DELETE_FLIGHT="delete from flightinformation where flightno=?";
	String UPDATE_PLACE="update flightinformation set dep_city=?, arr_city=? where flightno=?";
	String UPDATE_DATE="update flightinformation set dep_date=?, arr_date=? where flightno=?";
	String UPDATE_TIME="update flightinformation set dep_time=?, arr_time=? where flightno=?";
	String VALID_USER="select username,password from users where role=?";
}
